package com.capg.sixone;

public class BlankNameException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
