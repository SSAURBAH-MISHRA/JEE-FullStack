package com.capg.sixone;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.io.IOException;
public class Main {
	public static void main(String[] args) {
	
		Customer c = new Customer();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("*********Welcome to our app*********");
		try {
		  
			System.out.println("Enter firstName");
			String firstName = br.readLine();
				c.setFirstName(firstName);	
			System.out.println("enter lastName");
			String lastName = br.readLine();
			
			c.setLastName(lastName);
			if(firstName.isEmpty() || lastName.isEmpty()) {
				
						try {
							throw new BlankNameException();
						}catch(BlankNameException e){
							System.err.println("Name cannot be empty");
						}
					}
			System.out.println("enter Gender");
			String gender = br.readLine();
    		c.setGender(gender);
			System.out.println(c);
			
			
		} catch (NumberFormatException |IOException e ){
			// TODO: handle exception
		}
		/*System.out.println("id="+c.getCid());
		System.out.println("name="+c.getCname());
		System.out.println("price="+c.getCprice());
		*/
	}
}

