package com.capg;

import java.util.ArrayList;
import java.util.List;

public class Collection3 {
	public static void main(String[] args) {
		List<String> l1 = 	new ArrayList<String>();
		List<String> l2 =  new ArrayList<String>();
		l1.add("sushil");
		l1.add("suraj");
		l1.add("chirag");
		l1.add("shubham");
		System.out.println(l1);
        		
         l2.add("vikas");
         l2.add("kaushal");
         l2.add("kuldeep");
         l2.add("raj");
         System.out.println(l2);
         List<String> l3 = new ArrayList<String>();
         l3 = removeElements(l1,l2);
          System.out.println(l1);
	}
	public static List<String> removeElements(List<String> l1,List<String> l2){
		l1.removeAll(l2);
		return l1;
		
         
		
	}
	

}
