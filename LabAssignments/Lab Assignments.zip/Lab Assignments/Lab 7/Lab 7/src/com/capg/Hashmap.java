package com.capg;

import java.util.HashMap;
import java.util.Map;

public class Hashmap {
	public static void main(String[] args) {
	
        int a[] = {1,2,3,4};
        Squ s = new Squ();
        s.getsquares(a);
	}
}
class Squ{
	Map<Integer,Integer> getsquares(int a[]){
		

	HashMap<Integer,Integer> m = new HashMap<Integer,Integer>();
	
	for(int i:a)
	{
		m.put(i, i*i);
	}
	System.out.println(m);
	return null;
	
	}
	
}