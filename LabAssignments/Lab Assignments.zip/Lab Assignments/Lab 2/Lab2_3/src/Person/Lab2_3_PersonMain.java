package Person;

public class Lab2_3_PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab2_3_Person p = new Lab2_3_Person("Sushil", "Singh", 'M');
		System.out.println("First Name: " + p.getFirstName() + "\n");
		System.out.println("Last Name: " + p.getLastName() + "\n");
		System.out.println("Gender: " + p.getGender() + "\n");

	}

}
