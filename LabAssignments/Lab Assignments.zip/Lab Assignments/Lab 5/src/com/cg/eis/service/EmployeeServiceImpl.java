package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	Employee employee=new Employee();

	@Override
	public void createEmployee(int id, String name, double salary, String designation) {	
		employee= new Employee(id, name, salary, designation);
	}

	@Override
	public void insuranceScheme(double salary, String designation) {
		if (designation.equals("System Associate") && (salary > 5000.0 && salary < 20000.0))
			employee.setInsuranceScheme("C");
		else if (designation.equals("Programmer") && (salary >= 20000.0 && salary < 40000.0))
			employee.setInsuranceScheme("B");
		else if (designation.equals("Manager") && (salary >= 40000.0))
			employee.setInsuranceScheme("A");
		else if (designation.equals("Clerk") && (salary < 5000.0))
			employee.setInsuranceScheme("No");

	}

	@Override
	public Employee showEmployee() {
		return employee;
	}

}
