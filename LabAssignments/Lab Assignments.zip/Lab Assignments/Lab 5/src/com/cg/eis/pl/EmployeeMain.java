package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;

public class EmployeeMain {
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeService employeeService = new EmployeeServiceImpl();
		/*System.out.println("Enter your ID:");
		int empId = scanner.nextInt();
		System.out.println("Enter you Name: ");
		scanner.next();
		String empName = scanner.nextLine();
		System.out.println("Enter you Designation: ");
		String designation = scanner.nextLine();
		System.out.println("Enter you Salary: ");
		double salary = scanner.nextDouble();*/
		employeeService.createEmployee(101, "Sushil", 28000.0, "Programmer");
		employeeService.insuranceScheme(28000.0, "Programmer");
		System.out.println(employeeService.showEmployee());

	}

}
