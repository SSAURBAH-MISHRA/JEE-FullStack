package com.capg.Labfour_two.ui;

public class CurrentAccount extends Account {
	public void Withdraw(double Amount) {
  	    if(withdrawAccess(Amount)) {
  	       balance -= Amount;
  	 System.out.println("Updated Balance for currentAccount:"+getAccNum()+"is"+balance);
  	 System.out.println("");
  	    }
  	    else
  	    {
  	    	System.out.println("Over draft limit reached.cant with draw anymore");
  	    	System.out.println("");
  	    }
}
 public boolean withdrawAccess(double Amount) {
	 final double overdraftLimit = -1000;
 
   if((balance - Amount) <= overdraftLimit)
   {
	   return false;
	  }
   else
   {
	   return true;
   }
	   
   }

}
