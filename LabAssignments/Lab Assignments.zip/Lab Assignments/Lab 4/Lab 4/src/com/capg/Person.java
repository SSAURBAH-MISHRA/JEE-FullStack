package com.capg;

public class Person extends Account{
String Name;
float Age;
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public float getAge() {
	return Age;
}
public void setAge(float age) {
	Age = age;
}
@Override
public String toString() {
	return "Person [Name=" + Name + ", Age=" + Age + "]";
}

}

