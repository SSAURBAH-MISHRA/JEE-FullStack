package com.capg.Labfour_two.ui;

public class Bank {
public static void main(String[] args) {
	SavingsAccount a1 = new SavingsAccount();
	a1.setAccNum(111111);
	a1.setName("Sushil");
	a1.setAge(21);
	a1.setBalance(2000);
	System.out.println(a1.toString());
	
	CurrentAccount a2 = new CurrentAccount();
	a2.setAccNum(222222);
	a2.setName("Suraj");
	a2.setAge(21);
	a2.setBalance(12000);
	System.out.println(a2.toString());
	
	a1.Withdraw(1000);
	a2.Withdraw(12000);
	
	
	
}
}
