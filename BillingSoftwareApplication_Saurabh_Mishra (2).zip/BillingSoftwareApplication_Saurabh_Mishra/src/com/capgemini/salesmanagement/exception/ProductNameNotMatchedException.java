package com.capgemini.salesmanagement.exception;

public class ProductNameNotMatchedException extends Exception {

}
